package eig.model

enum OrderStatus {

    CANCELLED,
    DISPUTED,
    IN_PROCESS,
    ON_HOLD,
    RESOLVED,
    SHIPPED

}
