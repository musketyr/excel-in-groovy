package eig.model

enum Deal {

    SMALL,
    MEDIUM,
    LARGE

}
