package eig.tasks

import eig.model.Order
import org.modelcatalogue.spreadsheet.builder.api.SpreadsheetDefinition

import java.time.LocalTime

class ExcelIntegration {


    static SpreadsheetDefinition buildSalesReport(Map<Integer, Order> orders) {
        throw new UnsupportedOperationException("Exercise 1 hasn't started yet")
    }

    static SpreadsheetDefinition buildExecutiveReport(Map<Integer, Order> orders) {
        throw new UnsupportedOperationException("Exercise 2 hasn't started yet")
    }

    static SpreadsheetDefinition buildOrder(Order order) {
        throw new UnsupportedOperationException("Exercise 3 hasn't started yet")
    }

    static SpreadsheetDefinition fillData(Map<Integer, Order> orders) {
        throw new UnsupportedOperationException("Exercise 4 hasn't started yet")
    }

    static SpreadsheetDefinition drawSmiley() {
        throw new UnsupportedOperationException("Exercise 5 hasn't started yet")
    }

    static List<Order> loadOrders(InputStream inputStream) {
        throw new UnsupportedOperationException("Exercise 6 hasn't started yet")
    }

    static Map<String, Integer> loadProducts(InputStream stream) {
        throw new UnsupportedOperationException("Exercise 7 hasn't started yet")
    }

    static Set<LocalTime> loadDeparturesFromTheAirportWD(InputStream stream) {
        throw new UnsupportedOperationException("Exercise 8 hasn't started yet")
    }

}
